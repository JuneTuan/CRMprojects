-- MySQL dump 10.13  Distrib 8.4.8, for Linux (aarch64)
--
-- Host: localhost    Database: crm_db
-- ------------------------------------------------------
-- Server version	8.4.8

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `activity`
--

DROP TABLE IF EXISTS `activity`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity` (
  `activity_id` int NOT NULL AUTO_INCREMENT,
  `activity_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `activity_type` enum('游戏活动','积分活动','优惠券活动','混合活动') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '游戏活动',
  `activity_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `game_type` enum('slot-machine','blind-box','wheel','scratch-card','nine-grid') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `start_time` timestamp NOT NULL,
  `end_time` timestamp NOT NULL,
  `max_participants` int DEFAULT NULL,
  `max_draws_per_user` int DEFAULT NULL,
  `min_points` int NOT NULL DEFAULT '0',
  `free_draws` int DEFAULT '3' COMMENT '免费抽奖次数',
  `points_cost` int DEFAULT '10' COMMENT '积分消耗',
  `win_rate_config` json DEFAULT NULL,
  `status` enum('未开始','进行中','已结束') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '未开始',
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`activity_id`),
  UNIQUE KEY `IDX_b4465cfc0da51b7c2c51226fb5` (`activity_code`)
) ENGINE=InnoDB AUTO_INCREMENT=15 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity`
--

LOCK TABLES `activity` WRITE;
/*!40000 ALTER TABLE `activity` DISABLE KEYS */;
INSERT INTO `activity` VALUES (14,'ACT440837','游戏活动','元宵节活动','wheel','','2026-02-24 17:31:46','2026-02-28 00:00:00',NULL,NULL,0,3,10,'[{\"name\": \"谢谢\", \"prizeId\": 0, \"probability\": 10}, {\"name\": \"戒指\", \"prizeId\": 38, \"probability\": 10}, {\"name\": \"项链\", \"prizeId\": 37, \"probability\": 10}, {\"name\": \"10元代金券\", \"prizeId\": 36, \"probability\": 20}, {\"name\": \"50元代金券\", \"prizeId\": 35, \"probability\": 20}, {\"name\": \"100元代金券\", \"prizeId\": 32, \"probability\": 10}, {\"name\": \"电脑\", \"prizeId\": 34, \"probability\": 10}, {\"name\": \"手机\", \"prizeId\": 31, \"probability\": 10}]','进行中',NULL,NULL,'2026-02-24 09:31:51.436431','2026-02-24 09:48:39.000000');
/*!40000 ALTER TABLE `activity` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `activity_game`
--

DROP TABLE IF EXISTS `activity_game`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_game` (
  `activity_game_id` int NOT NULL AUTO_INCREMENT,
  `activity_id` int NOT NULL,
  `game_type_id` int NOT NULL,
  `config` json DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`activity_game_id`),
  KEY `FK_713499be7d416876daf2004981d` (`activity_id`),
  KEY `FK_9967b80ef63ecc1ecd01ea5ec6a` (`game_type_id`),
  CONSTRAINT `FK_713499be7d416876daf2004981d` FOREIGN KEY (`activity_id`) REFERENCES `activity` (`activity_id`),
  CONSTRAINT `FK_9967b80ef63ecc1ecd01ea5ec6a` FOREIGN KEY (`game_type_id`) REFERENCES `game_type` (`game_type_id`)
) ENGINE=InnoDB AUTO_INCREMENT=21 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_game`
--

LOCK TABLES `activity_game` WRITE;
/*!40000 ALTER TABLE `activity_game` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_game` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `coupon`
--

DROP TABLE IF EXISTS `coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `coupon` (
  `coupon_id` int NOT NULL AUTO_INCREMENT,
  `coupon_code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `coupon_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(10,2) NOT NULL,
  `type` enum('代金券','实物券') COLLATE utf8mb4_unicode_ci NOT NULL,
  `start_time` timestamp NOT NULL,
  `end_time` timestamp NOT NULL,
  `total_quantity` int NOT NULL,
  `remaining_quantity` int NOT NULL,
  `max_uses_per_user` int DEFAULT '1',
  `min_level` enum('普通会员','白银会员','黄金会员','钻石会员') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `applicable_products` text COLLATE utf8mb4_unicode_ci,
  `status` enum('未开始','进行中','已结束') COLLATE utf8mb4_unicode_ci DEFAULT '未开始',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`coupon_id`),
  UNIQUE KEY `IDX_8927dc8fa6af6c5182c36cb07c` (`coupon_code`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `coupon`
--

LOCK TABLES `coupon` WRITE;
/*!40000 ALTER TABLE `coupon` DISABLE KEYS */;
INSERT INTO `coupon` VALUES (1,'WELCOME2024','新用户欢迎券',50.00,'代金券','2024-01-01 00:00:00','2024-12-31 23:59:59',1000,950,1,'普通会员',NULL,'已结束',NULL,'2026-02-23 10:18:44.000000','2026-02-23 10:19:42.000000'),(2,'SPRING2024','春节特惠券',100.00,'代金券','2024-02-01 00:00:00','2024-02-29 23:59:59',500,480,1,'普通会员',NULL,'已结束',NULL,'2026-02-23 10:18:44.000000','2026-02-23 10:19:42.000000'),(3,'MEMBER2024','会员专享券',80.00,'代金券','2024-01-01 00:00:00','2024-12-31 23:59:59',300,270,1,'白银会员',NULL,'已结束',NULL,'2026-02-23 10:18:44.000000','2026-02-23 10:19:42.000000'),(4,'FLASH2024','限时秒杀券',200.00,'代金券','2024-03-01 00:00:00','2024-03-31 23:59:59',200,190,1,'黄金会员',NULL,'已结束',NULL,'2026-02-23 10:18:44.000000','2026-02-23 10:19:42.000000'),(5,'CPN1771842529602','200积分',200.00,'实物券','2026-02-23 18:28:50','2027-02-23 18:28:50',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 10:28:49.603837','2026-02-23 10:28:49.603837'),(6,'CPN1771842537257','100积分',100.00,'实物券','2026-02-23 18:28:57','2027-02-23 18:28:57',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 10:28:57.258578','2026-02-23 10:28:57.258578'),(7,'CPN1771843829406','100积分',100.00,'实物券','2026-02-23 18:50:29','2027-02-23 18:50:29',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 10:50:29.407506','2026-02-23 10:50:29.407506'),(8,'CPN1771847084904','收集',5000.00,'实物券','2026-02-23 19:44:45','2027-02-23 19:44:45',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 11:44:44.906136','2026-02-23 11:44:44.906136'),(9,'CPN1771847102584','100元代金券',0.00,'代金券','2026-02-23 19:45:03','2027-02-23 19:45:03',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 11:45:02.585361','2026-02-23 11:45:02.585361'),(10,'CPN1771848096025','收集',5000.00,'实物券','2026-02-23 20:01:36','2027-02-23 20:01:36',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:01:36.026361','2026-02-23 12:01:36.026361'),(11,'CPN1771848200119','收集',5000.00,'实物券','2026-02-23 20:03:20','2027-02-23 20:03:20',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:03:20.120466','2026-02-23 12:03:20.120466'),(12,'CPN1771848224395','收集',5000.00,'实物券','2026-02-23 20:03:44','2027-02-23 20:03:44',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:03:44.396038','2026-02-23 12:03:44.396038'),(13,'CPN1771848224483','收集',5000.00,'实物券','2026-02-23 20:03:44','2027-02-23 20:03:44',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:03:44.484484','2026-02-23 12:03:44.484484'),(14,'CPN1771848469257','收集',5000.00,'实物券','2026-02-23 20:07:49','2027-02-23 20:07:49',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:07:49.257778','2026-02-23 12:07:49.257778'),(15,'CPN1771848686603','收集',5000.00,'实物券','2026-02-23 20:11:27','2027-02-23 20:11:27',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:11:26.604320','2026-02-23 12:11:26.604320'),(16,'CPN1771848951081','100元代金券',0.00,'代金券','2026-02-23 20:15:51','2027-02-23 20:15:51',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:15:51.082936','2026-02-23 12:15:51.082936'),(17,'CPN1771849620230','收集',5000.00,'实物券','2026-02-23 20:27:00','2027-02-23 20:27:00',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:27:00.231981','2026-02-23 12:27:00.231981'),(18,'CPN1771849620323','收集',5000.00,'实物券','2026-02-23 20:27:00','2027-02-23 20:27:00',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 12:27:00.323956','2026-02-23 12:27:00.323956'),(19,'CPN1771852626500','100元代金券',0.00,'代金券','2026-02-23 21:17:07','2027-02-23 21:17:07',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 13:17:06.501909','2026-02-23 13:17:06.501909'),(20,'CPN1771852655463','100元代金券',0.00,'代金券','2026-02-23 21:17:35','2027-02-23 21:17:35',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 13:17:35.464737','2026-02-23 13:17:35.464737'),(21,'CPN1771853019420','收集',5000.00,'实物券','2026-02-23 21:23:39','2027-02-23 21:23:39',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 13:23:39.421719','2026-02-23 13:23:39.421719'),(22,'CPN1771853033356','钥匙扣',10.00,'实物券','2026-02-23 21:23:53','2027-02-23 21:23:53',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 13:23:53.357294','2026-02-23 13:23:53.357294'),(23,'CPN1771853376143','收集',5000.00,'实物券','2026-02-23 21:29:36','2027-02-23 21:29:36',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 13:29:36.145230','2026-02-23 13:29:36.145230'),(24,'CPN1771855857792','100元代金券',0.00,'代金券','2026-02-23 22:10:58','2027-02-23 22:10:58',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 14:10:57.793400','2026-02-23 14:10:57.793400'),(25,'CPN1771860151088','收集',5000.00,'实物券','2026-02-23 23:22:31','2027-02-23 23:22:31',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-23 15:22:31.089455','2026-02-23 15:22:31.089455'),(26,'CPN1771924765783','100元代金券',0.00,'代金券','2026-02-24 17:19:26','2027-02-24 17:19:26',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-24 09:19:25.784873','2026-02-24 09:19:25.784873'),(27,'CPN1771924864942','100元代金券',0.00,'代金券','2026-02-24 17:21:05','2027-02-24 17:21:05',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-24 09:21:04.943964','2026-02-24 09:21:04.943964'),(28,'CPN1771925785011','10元代金券',0.00,'代金券','2026-02-24 17:36:25','2027-02-24 17:36:25',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-24 09:36:25.012691','2026-02-24 09:36:25.012691'),(29,'CPN1771926717491','100元代金券',0.00,'代金券','2026-02-24 17:51:57','2027-02-24 17:51:57',1,1,1,NULL,NULL,'进行中',NULL,'2026-02-24 09:51:57.492638','2026-02-24 09:51:57.492638');
/*!40000 ALTER TABLE `coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer`
--

DROP TABLE IF EXISTS `customer`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer` (
  `customer_id` int NOT NULL AUTO_INCREMENT,
  `customer_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '',
  `customer_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `avatar` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT '',
  `points` bigint NOT NULL DEFAULT '0',
  `member_level_id` int DEFAULT NULL,
  `total_consumption` decimal(10,2) NOT NULL DEFAULT '0.00',
  `level` enum('普通会员','白银会员','黄金会员','钻石会员') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '普通会员',
  `address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `source` enum('后台新增','H5注册') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '后台新增',
  `remark` text COLLATE utf8mb4_unicode_ci,
  `owner_id` int DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`customer_id`),
  UNIQUE KEY `IDX_ca90eb4361711ae10f6753fcb5` (`customer_code`),
  KEY `FK_5fe6fc4b74a90db7f6b74c05db5` (`owner_id`),
  KEY `FK_404a437803d82a9c645bb11421e` (`member_level_id`),
  CONSTRAINT `FK_404a437803d82a9c645bb11421e` FOREIGN KEY (`member_level_id`) REFERENCES `member_level` (`level_id`),
  CONSTRAINT `FK_5fe6fc4b74a90db7f6b74c05db5` FOREIGN KEY (`owner_id`) REFERENCES `user` (`user_id`)
) ENGINE=InnoDB AUTO_INCREMENT=10 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer`
--

LOCK TABLES `customer` WRITE;
/*!40000 ALTER TABLE `customer` DISABLE KEYS */;
INSERT INTO `customer` VALUES (3,'test','$2b$10$VxL3Qv1rAT9WGBy8c.bmK.vO7youqc.H.i4UqShx9JU5sXZS9wGAy','测试客户','13800138002','test@junlite.com',NULL,'',1031925,4,1036198.00,'普通会员','北京市朝阳区','H5注册','测试客户',NULL,1,NULL,'2026-02-23 10:09:33.000000','2026-02-24 09:51:57.000000'),(4,'cus111','$2b$10$bQoWh.uBg.z11fkxOwQbqOIboAaDmVJ4D3JpQmqVQjio2IPjEoe1W','测试客户2222','13800001981','1650@qq.com',NULL,'',0,1,0.00,'普通会员',NULL,'H5注册','',NULL,1,NULL,'2026-02-23 10:12:54.711205','2026-02-23 12:51:10.000000'),(9,'h5test','$2b$10$ZvROGiLaTJ1.aURTcgd3fe3o2JVfpb2VFek/3oYYtI.SdXA6m9lc.','H5测试用户','13900139999',NULL,NULL,'',0,1,0.00,'普通会员',NULL,'H5注册',NULL,NULL,1,NULL,'2026-02-23 14:09:26.549264','2026-02-23 14:10:57.000000');
/*!40000 ALTER TABLE `customer` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `customer_coupon`
--

DROP TABLE IF EXISTS `customer_coupon`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `customer_coupon` (
  `customer_coupon_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `coupon_id` int NOT NULL,
  `status` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '未使用',
  `received_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `used_at` datetime DEFAULT NULL,
  `order_id` int DEFAULT NULL,
  PRIMARY KEY (`customer_coupon_id`),
  KEY `FK_1153e47bbf8181c91c4460d0262` (`customer_id`),
  KEY `FK_cb93c4d17ee342bcaf37f414a19` (`coupon_id`),
  CONSTRAINT `FK_1153e47bbf8181c91c4460d0262` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `FK_cb93c4d17ee342bcaf37f414a19` FOREIGN KEY (`coupon_id`) REFERENCES `coupon` (`coupon_id`)
) ENGINE=InnoDB AUTO_INCREMENT=30 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `customer_coupon`
--

LOCK TABLES `customer_coupon` WRITE;
/*!40000 ALTER TABLE `customer_coupon` DISABLE KEYS */;
INSERT INTO `customer_coupon` VALUES (1,3,1,'已使用','2026-02-23 10:18:44','2026-02-23 10:00:00',NULL),(2,3,2,'未使用','2026-02-23 10:18:44',NULL,NULL),(3,3,3,'未使用','2026-02-23 10:18:44',NULL,NULL),(4,3,4,'未使用','2026-02-23 10:18:44',NULL,NULL),(5,4,5,'未使用','2026-02-23 10:28:49',NULL,NULL),(6,4,6,'未使用','2026-02-23 10:28:57',NULL,NULL),(7,3,7,'未使用','2026-02-23 10:50:29',NULL,NULL),(8,4,8,'未使用','2026-02-23 11:44:44',NULL,NULL),(9,4,9,'已使用','2026-02-23 11:45:02','2026-02-23 19:46:11',NULL),(10,3,10,'未使用','2026-02-23 12:01:36',NULL,NULL),(11,3,11,'未使用','2026-02-23 12:03:20',NULL,NULL),(12,3,12,'未使用','2026-02-23 12:03:44',NULL,NULL),(13,3,13,'未使用','2026-02-23 12:03:44',NULL,NULL),(14,3,14,'未使用','2026-02-23 12:07:49',NULL,NULL),(15,3,15,'未使用','2026-02-23 12:11:26',NULL,NULL),(16,4,16,'未使用','2026-02-23 12:15:51',NULL,NULL),(17,3,17,'未使用','2026-02-23 12:27:00',NULL,NULL),(18,3,18,'未使用','2026-02-23 12:27:00',NULL,NULL),(19,3,19,'未使用','2026-02-23 13:17:06',NULL,NULL),(20,3,20,'未使用','2026-02-23 13:17:35',NULL,NULL),(21,3,21,'未使用','2026-02-23 13:23:39',NULL,NULL),(22,3,22,'未使用','2026-02-23 13:23:53',NULL,NULL),(23,3,23,'未使用','2026-02-23 13:29:36',NULL,NULL),(24,9,24,'未使用','2026-02-23 14:10:57',NULL,NULL),(25,3,25,'未使用','2026-02-23 15:22:31',NULL,NULL),(26,3,26,'未使用','2026-02-24 09:19:25',NULL,NULL),(27,3,27,'未使用','2026-02-24 09:21:04',NULL,NULL),(28,3,28,'未使用','2026-02-24 09:36:25',NULL,NULL),(29,3,29,'未使用','2026-02-24 09:51:57',NULL,NULL);
/*!40000 ALTER TABLE `customer_coupon` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_prize`
--

DROP TABLE IF EXISTS `game_prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_prize` (
  `game_prize_id` int NOT NULL AUTO_INCREMENT,
  `activity_game_id` int NOT NULL,
  `prize_id` int NOT NULL,
  `probability` decimal(5,2) NOT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`game_prize_id`),
  KEY `FK_37cbebd36eb318e70894f9d06fa` (`activity_game_id`),
  KEY `FK_3253545f12e86603364ffe11aa6` (`prize_id`),
  CONSTRAINT `FK_3253545f12e86603364ffe11aa6` FOREIGN KEY (`prize_id`) REFERENCES `prize` (`prize_id`),
  CONSTRAINT `FK_37cbebd36eb318e70894f9d06fa` FOREIGN KEY (`activity_game_id`) REFERENCES `activity_game` (`activity_game_id`)
) ENGINE=InnoDB AUTO_INCREMENT=140 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_prize`
--

LOCK TABLES `game_prize` WRITE;
/*!40000 ALTER TABLE `game_prize` DISABLE KEYS */;
/*!40000 ALTER TABLE `game_prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `game_type`
--

DROP TABLE IF EXISTS `game_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `game_type` (
  `game_type_id` int NOT NULL AUTO_INCREMENT,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `game_type_name` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `icon` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `deleted_at` datetime DEFAULT NULL,
  `created_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` datetime(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`game_type_id`),
  UNIQUE KEY `IDX_30de2554614e4b98bc1dc5c2bd` (`type`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `game_type`
--

LOCK TABLES `game_type` WRITE;
/*!40000 ALTER TABLE `game_type` DISABLE KEYS */;
INSERT INTO `game_type` VALUES (1,'slot-machine','老虎机','🎰','经典老虎机游戏，转动老虎机赢取奖品',1,NULL,'2026-02-23 10:10:46.000000','2026-02-23 10:10:46.000000'),(2,'wheel','大转盘','🎡','幸运大转盘，指针停在哪里就获得什么奖品',1,NULL,'2026-02-23 10:10:46.000000','2026-02-23 10:10:46.000000'),(4,'blind-box','盲盒','🎁','神秘盲盒，打开看看里面有什么惊喜',1,NULL,'2026-02-23 11:41:35.587019','2026-02-23 11:41:35.587019'),(5,'nine-grid','九宫格','🎯','经典九宫格抽奖，点击格子赢取奖品',1,NULL,'2026-02-23 11:41:35.587019','2026-02-23 11:41:35.587019'),(6,'scratch-card','刮刮卡','🃏','刮开涂层，发现你的幸运奖品',1,NULL,'2026-02-23 11:41:35.587019','2026-02-23 11:41:35.587019');
/*!40000 ALTER TABLE `game_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `lottery_record`
--

DROP TABLE IF EXISTS `lottery_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `lottery_record` (
  `lottery_record_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `activity_id` int NOT NULL,
  `game_type_id` int NOT NULL,
  `prize_id` int DEFAULT NULL,
  `prize_name` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `coupon_id` int DEFAULT NULL,
  `status` enum('未领取','已领取','已过期','未中奖') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '未领取',
  `draw_count` int NOT NULL DEFAULT '1',
  `cost_points` int NOT NULL DEFAULT '0',
  `draw_time` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `claim_time` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`lottery_record_id`),
  KEY `FK_286639bea62749dfd24efb1af15` (`customer_id`),
  KEY `FK_4f6420438a55cf498adf522e7c3` (`activity_id`),
  KEY `FK_3ffd87b74b933ac0070d5f0d86e` (`game_type_id`),
  KEY `FK_fce8f703a877ccb865e77c300f9` (`prize_id`),
  CONSTRAINT `FK_286639bea62749dfd24efb1af15` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`),
  CONSTRAINT `FK_3ffd87b74b933ac0070d5f0d86e` FOREIGN KEY (`game_type_id`) REFERENCES `game_type` (`game_type_id`),
  CONSTRAINT `FK_4f6420438a55cf498adf522e7c3` FOREIGN KEY (`activity_id`) REFERENCES `activity` (`activity_id`),
  CONSTRAINT `FK_fce8f703a877ccb865e77c300f9` FOREIGN KEY (`prize_id`) REFERENCES `prize` (`prize_id`)
) ENGINE=InnoDB AUTO_INCREMENT=59 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `lottery_record`
--

LOCK TABLES `lottery_record` WRITE;
/*!40000 ALTER TABLE `lottery_record` DISABLE KEYS */;
INSERT INTO `lottery_record` VALUES (57,3,14,2,36,'10元代金券',NULL,'已领取',1,0,'2026-02-24 09:36:25','2026-02-24 17:36:37'),(58,3,14,2,32,'100元代金券',NULL,'已领取',1,0,'2026-02-24 09:51:57','2026-02-24 17:52:09');
/*!40000 ALTER TABLE `lottery_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_level`
--

DROP TABLE IF EXISTS `member_level`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_level` (
  `level_id` int NOT NULL AUTO_INCREMENT,
  `level_name` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `level_code` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL,
  `min_consumption` decimal(10,2) NOT NULL DEFAULT '0.00',
  `icon_code` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `benefits_config` json DEFAULT NULL,
  `sort_order` int NOT NULL DEFAULT '0',
  `is_active` tinyint NOT NULL DEFAULT '1',
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`level_id`),
  UNIQUE KEY `IDX_69dc34ebeed86accf376388b23` (`level_code`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_level`
--

LOCK TABLES `member_level` WRITE;
/*!40000 ALTER TABLE `member_level` DISABLE KEYS */;
INSERT INTO `member_level` VALUES (1,'普通会员','NORMAL',0.00,NULL,NULL,1,1,'2026-02-23 10:09:33.000000','2026-02-23 10:09:33.000000'),(2,'白银会员','SILVER',1000.00,NULL,NULL,2,1,'2026-02-23 10:09:33.000000','2026-02-23 10:09:33.000000'),(3,'黄金会员','GOLD',5000.00,NULL,NULL,3,1,'2026-02-23 10:09:33.000000','2026-02-23 10:09:33.000000'),(4,'钻石会员','DIAMOND',10000.00,NULL,NULL,4,1,'2026-02-23 10:09:33.000000','2026-02-23 10:09:33.000000');
/*!40000 ALTER TABLE `member_level` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `member_level_log`
--

DROP TABLE IF EXISTS `member_level_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `member_level_log` (
  `log_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `old_level_id` int DEFAULT NULL,
  `new_level_id` int NOT NULL,
  `change_type` enum('auto_upgrade','manual_adjust','manual_downgrade') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'auto_upgrade',
  `old_consumption` decimal(10,2) DEFAULT NULL,
  `new_consumption` decimal(10,2) DEFAULT NULL,
  `remark` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operator_id` int DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`log_id`),
  KEY `FK_ed057dc6b3fe09c81385afee1ff` (`customer_id`),
  KEY `FK_730839242e2aedd9175f4812125` (`old_level_id`),
  KEY `FK_d4bbd553f704e9080e42b43bd58` (`new_level_id`),
  KEY `FK_52060e32147185a93c60d8f9588` (`operator_id`),
  CONSTRAINT `FK_52060e32147185a93c60d8f9588` FOREIGN KEY (`operator_id`) REFERENCES `user` (`user_id`),
  CONSTRAINT `FK_730839242e2aedd9175f4812125` FOREIGN KEY (`old_level_id`) REFERENCES `member_level` (`level_id`),
  CONSTRAINT `FK_d4bbd553f704e9080e42b43bd58` FOREIGN KEY (`new_level_id`) REFERENCES `member_level` (`level_id`),
  CONSTRAINT `FK_ed057dc6b3fe09c81385afee1ff` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `member_level_log`
--

LOCK TABLES `member_level_log` WRITE;
/*!40000 ALTER TABLE `member_level_log` DISABLE KEYS */;
INSERT INTO `member_level_log` VALUES (1,3,1,2,'auto_upgrade',2999.00,2999.00,'自动升级',NULL,NULL,'2026-02-23 10:33:40.115474'),(2,3,2,4,'auto_upgrade',20398.00,20398.00,'自动升级',NULL,NULL,'2026-02-24 09:29:31.215204');
/*!40000 ALTER TABLE `member_level_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order`
--

DROP TABLE IF EXISTS `order`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order` (
  `order_id` int NOT NULL AUTO_INCREMENT,
  `order_no` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `customer_id` int NOT NULL,
  `coupon_id` int DEFAULT NULL,
  `coupon_discount_amount` decimal(10,2) DEFAULT NULL,
  `total_amount` decimal(10,2) NOT NULL,
  `actual_amount` decimal(10,2) NOT NULL,
  `status` varchar(20) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '待支付',
  `payment_method` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_time` timestamp NULL DEFAULT NULL,
  `shipping_address` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_points` tinyint NOT NULL DEFAULT '1',
  `points` int NOT NULL DEFAULT '0',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`order_id`),
  UNIQUE KEY `IDX_97a9994740485648cc0eb0007a` (`order_no`),
  KEY `FK_cd7812c96209c5bdd48a6b858b0` (`customer_id`),
  KEY `FK_baced9282892a60354aaa789fb4` (`coupon_id`),
  CONSTRAINT `FK_baced9282892a60354aaa789fb4` FOREIGN KEY (`coupon_id`) REFERENCES `coupon` (`coupon_id`),
  CONSTRAINT `FK_cd7812c96209c5bdd48a6b858b0` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order`
--

LOCK TABLES `order` WRITE;
/*!40000 ALTER TABLE `order` DISABLE KEYS */;
INSERT INTO `order` VALUES (1,'ORD20260223001',3,NULL,NULL,15800.00,15800.00,'已完成','微信支付','2026-02-23 10:30:00','北京市朝阳区建国路88号',1,100,NULL,'2026-02-23 10:00:00.000000','2026-02-23 10:37:43.589292'),(2,'ORD20260223002',3,NULL,NULL,899.00,899.00,'已完成','支付宝','2026-02-23 11:00:00','北京市朝阳区建国路88号',1,90,NULL,'2026-02-23 10:30:00.000000','2026-02-23 11:00:00.000000'),(3,'ORD20260223003',3,NULL,NULL,399.00,399.00,'待发货','微信支付',NULL,'北京市朝阳区建国路88号',1,40,NULL,'2026-02-23 11:30:00.000000','2026-02-23 11:30:00.000000'),(4,'ORD20260223004',3,NULL,NULL,1599.00,1599.00,'已完成',NULL,NULL,'北京市朝阳区建国路88号',0,160,NULL,'2026-02-23 12:00:00.000000','2026-02-24 09:25:03.000000'),(5,'ORD20260223005',3,NULL,NULL,2999.00,2999.00,'已完成',NULL,NULL,'北京市朝阳区建国路88号',1,300,NULL,'2026-02-23 12:30:00.000000','2026-02-23 10:33:40.000000'),(7,'ORD_1771925350173',3,NULL,NULL,15800.00,15800.00,'已完成',NULL,NULL,'上海陆家嘴',1,15800,NULL,'2026-02-24 09:29:31.179367','2026-02-24 09:29:31.179367'),(8,'ORD_1771926467908',3,NULL,NULL,1015800.00,1015800.00,'已完成',NULL,NULL,'SH',1,1015800,NULL,'2026-02-24 09:48:09.297662','2026-02-24 09:48:09.297662');
/*!40000 ALTER TABLE `order` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `order_item`
--

DROP TABLE IF EXISTS `order_item`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `order_item` (
  `order_item_id` int NOT NULL AUTO_INCREMENT,
  `order_id` int NOT NULL,
  `product_id` int DEFAULT NULL,
  `product_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_image` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int NOT NULL,
  `unit_price` decimal(10,2) NOT NULL,
  `subtotal` decimal(10,2) NOT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`order_item_id`),
  KEY `FK_e9674a6053adbaa1057848cddfa` (`order_id`),
  KEY `FK_5e17c017aa3f5164cb2da5b1c6b` (`product_id`),
  CONSTRAINT `FK_5e17c017aa3f5164cb2da5b1c6b` FOREIGN KEY (`product_id`) REFERENCES `product` (`product_id`),
  CONSTRAINT `FK_e9674a6053adbaa1057848cddfa` FOREIGN KEY (`order_id`) REFERENCES `order` (`order_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `order_item`
--

LOCK TABLES `order_item` WRITE;
/*!40000 ALTER TABLE `order_item` DISABLE KEYS */;
INSERT INTO `order_item` VALUES (1,1,51,'Tasaki Linkage 珍珠项链','https://example.com/images/iphone15.jpg',1,15800.00,15800.00,'2026-02-23 10:18:44.000000'),(2,2,6,'男士商务休闲西装','https://example.com/images/mensuit.jpg',1,899.00,899.00,'2026-02-23 10:18:44.000000'),(3,3,7,'女士连衣裙','https://example.com/images/dress.jpg',1,399.00,399.00,'2026-02-23 10:18:44.000000'),(6,5,11,'智能扫地机器人','https://example.com/images/robot.jpg',1,2999.00,2999.00,'2026-02-23 10:33:40.094616'),(7,4,12,'空气净化器','https://example.com/images/purifier.jpg',1,1599.00,1599.00,'2026-02-24 09:25:03.153805'),(8,7,51,'Tasaki Linkage 珍珠项链','https://example.com/images/tasaki_linkage_necklace.jpg',1,15800.00,15800.00,'2026-02-24 09:29:31.187132'),(9,8,51,'Tasaki Linkage 珍珠项链','https://example.com/images/tasaki_linkage_necklace.jpg',1,15800.00,15800.00,'2026-02-24 09:48:09.306859'),(10,8,76,'手镯','',1,1000000.00,1000000.00,'2026-02-24 09:48:09.316008');
/*!40000 ALTER TABLE `order_item` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `permission`
--

DROP TABLE IF EXISTS `permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `permission` (
  `permission_id` int NOT NULL AUTO_INCREMENT,
  `permission_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`permission_id`),
  UNIQUE KEY `IDX_e38116c36ed93070edc6347846` (`permission_name`),
  UNIQUE KEY `IDX_30e166e8c6359970755c5727a2` (`code`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `permission`
--

LOCK TABLES `permission` WRITE;
/*!40000 ALTER TABLE `permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `point_record`
--

DROP TABLE IF EXISTS `point_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `point_record` (
  `point_record_id` int NOT NULL AUTO_INCREMENT,
  `customer_id` int NOT NULL,
  `type` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `points` int NOT NULL,
  `balance` int NOT NULL,
  `reason` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `expire_time` timestamp NULL DEFAULT NULL,
  `is_expired` tinyint DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`point_record_id`),
  KEY `FK_4bba0476baef50b4a9efbe51e27` (`customer_id`),
  CONSTRAINT `FK_4bba0476baef50b4a9efbe51e27` FOREIGN KEY (`customer_id`) REFERENCES `customer` (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `point_record`
--

LOCK TABLES `point_record` WRITE;
/*!40000 ALTER TABLE `point_record` DISABLE KEYS */;
INSERT INTO `point_record` VALUES (1,3,'注册奖励',100,100,'新用户注册赠送100积分',NULL,NULL,'2026-02-23 10:18:44'),(2,3,'订单奖励',100,200,'订单ORD20260223001完成，获得100积分',NULL,NULL,'2026-02-23 10:30:00'),(3,3,'订单奖励',90,290,'订单ORD20260223002完成，获得90积分',NULL,NULL,'2026-02-23 11:00:00'),(4,3,'抽奖消费',-100,190,'参与幸运抽奖活动，消耗100积分',NULL,NULL,'2026-02-23 11:15:00'),(5,3,'订单完成',300,400,'订单 ORD20260223005 完成获得积分',NULL,NULL,NULL),(6,3,'订单完成',15800,16125,'订单 ORD_1771925350173 完成获得积分',NULL,NULL,NULL),(7,3,'订单完成',1015800,1031925,'订单 ORD_1771926467908 完成获得积分',NULL,NULL,NULL);
/*!40000 ALTER TABLE `point_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `prize`
--

DROP TABLE IF EXISTS `prize`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `prize` (
  `prize_id` int NOT NULL AUTO_INCREMENT,
  `prize_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `type` enum('券','实物','积分') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` decimal(10,2) NOT NULL DEFAULT '0.00',
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quantity` int NOT NULL,
  `remaining_quantity` int NOT NULL,
  `status` enum('可用','不可用') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '可用',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`prize_id`)
) ENGINE=InnoDB AUTO_INCREMENT=39 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `prize`
--

LOCK TABLES `prize` WRITE;
/*!40000 ALTER TABLE `prize` DISABLE KEYS */;
INSERT INTO `prize` VALUES (31,'手机','','实物',5000.00,NULL,100,88,'可用',NULL,'2026-02-23 10:53:13.649421','2026-02-24 09:27:08.000000'),(32,'100元代金券','','券',0.00,NULL,999999,999991,'可用',NULL,'2026-02-23 10:53:28.170197','2026-02-24 09:51:57.000000'),(33,'钥匙扣','','实物',10.00,NULL,100,99,'可用',NULL,'2026-02-23 10:53:41.598721','2026-02-23 13:23:53.000000'),(34,'电脑','','实物',2000.00,NULL,100,100,'可用',NULL,'2026-02-24 09:26:25.662902','2026-02-24 09:26:25.662902'),(35,'50元代金券','','券',0.00,NULL,999999,999999,'可用',NULL,'2026-02-24 09:29:56.328717','2026-02-24 09:29:56.328717'),(36,'10元代金券','','券',0.00,NULL,999999,999998,'可用',NULL,'2026-02-24 09:30:07.440814','2026-02-24 09:36:25.000000'),(37,'项链','','实物',1000.00,NULL,100,100,'可用',NULL,'2026-02-24 09:30:20.725771','2026-02-24 09:30:20.725771'),(38,'戒指','','实物',1000.00,NULL,100,100,'可用',NULL,'2026-02-24 09:30:38.022754','2026-02-24 09:30:38.022754');
/*!40000 ALTER TABLE `prize` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product`
--

DROP TABLE IF EXISTS `product`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product` (
  `product_id` int NOT NULL AUTO_INCREMENT,
  `product_code` varchar(32) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_name` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci,
  `price` decimal(10,2) NOT NULL,
  `stock` int DEFAULT NULL,
  `category_id` int DEFAULT NULL,
  `status` enum('上架','下架') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image_url` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`product_id`),
  UNIQUE KEY `IDX_fb912a8e66bfe036057ba4651f` (`product_code`),
  KEY `FK_0dce9bc93c2d2c399982d04bef1` (`category_id`),
  CONSTRAINT `FK_0dce9bc93c2d2c399982d04bef1` FOREIGN KEY (`category_id`) REFERENCES `product_category` (`product_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=77 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product`
--

LOCK TABLES `product` WRITE;
/*!40000 ALTER TABLE `product` DISABLE KEYS */;
INSERT INTO `product` VALUES (6,'P006','男士商务休闲西装','修身剪裁，透气面料，适合商务场合',899.00,200,9,'上架','https://example.com/images/mensuit.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.203190'),(7,'P007','女士连衣裙','时尚设计，舒适面料，多种颜色可选',399.00,150,10,'上架','https://example.com/images/dress.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.204115'),(8,'P008','Nike Air Max 270','经典运动鞋，舒适透气，适合日常运动',899.00,120,11,'上架','https://example.com/images/nike.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.205534'),(9,'P009','Adidas Ultraboost','Boost科技，缓震回弹，适合跑步',1099.00,100,11,'上架','https://example.com/images/adidas.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.205534'),(10,'P010','男士牛仔裤','经典直筒版型，耐磨面料，百搭款式',299.00,300,3,'上架','https://example.com/images/jeans.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.207686'),(11,'P011','智能扫地机器人','激光导航，自动充电，APP控制',2999.00,50,4,'上架','https://example.com/images/robot.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.208410'),(12,'P012','空气净化器','HEPA滤网，静音运行，智能监测',1599.00,80,4,'上架','https://example.com/images/purifier.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.208410'),(13,'P013','智能台灯','护眼光源，多档调光，USB充电',199.00,200,4,'上架','https://example.com/images/lamp.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.208410'),(14,'P014','人体工学办公椅','网布透气，多角度调节，护腰设计',1299.00,60,4,'上架','https://example.com/images/chair.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.208410'),(15,'P015','床上用品四件套','纯棉面料，亲肤舒适，简约设计',399.00,150,4,'上架','https://example.com/images/bedding.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.208410'),(16,'P016','有机茶叶礼盒','精选高山茶，清香回甘，送礼佳品',599.00,100,5,'上架','https://example.com/images/tea.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209046'),(17,'P017','进口红酒','法国波尔多产区，口感醇厚，适合收藏',899.00,80,5,'上架','https://example.com/images/wine.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209046'),(18,'P018','坚果礼盒','多种坚果组合，营养丰富，健康零食',299.00,200,5,'上架','https://example.com/images/nuts.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209046'),(19,'P019','进口咖啡豆','阿拉比卡咖啡豆，现磨现泡，香浓醇厚',199.00,150,5,'上架','https://example.com/images/coffee.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209046'),(20,'P020','有机蜂蜜','天然纯正，营养丰富，健康养生',159.00,180,5,'上架','https://example.com/images/honey.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209046'),(21,'P021','精华液套装','补水保湿，提亮肤色，改善肌肤',699.00,120,6,'上架','https://example.com/images/serum.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209830'),(22,'P022','面膜礼盒','多种功效面膜，深层清洁，滋润肌肤',399.00,200,6,'上架','https://example.com/images/mask.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209830'),(23,'P023','口红套装','多种色号，持久不脱色，滋润不干燥',499.00,150,6,'上架','https://example.com/images/lipstick.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209830'),(24,'P024','防晒霜','SPF50+，防水防汗，清爽不油腻',199.00,250,6,'上架','https://example.com/images/sunscreen.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209830'),(25,'P025','洗面奶','温和清洁，深层去油，适合各种肤质',99.00,300,6,'上架','https://example.com/images/cleanser.jpg',NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:19:38.209830'),(51,'J001','Tasaki Linkage 珍珠项链','18K樱花金与18K白金交织，镶嵌高品质钻石与阿古屋珍珠，灵感源自珍珠贝笼造型',15800.00,18,22,'上架','https://example.com/images/tasaki_linkage_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-24 09:48:09.000000'),(52,'J002','Tasaki Fluid 流动珍珠项链','以流动起伏的黄金线条围裹Akoya珍珠，诗意演绎潮汐起落间珍珠在母贝中逐渐形成的历程',12800.00,25,22,'上架','https://example.com/images/tasaki_fluid_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.496605'),(53,'J003','Tasaki Ambivalent 链环珍珠项链','长短不一的黄金曲线穿过整齐统一的圆形链环，两端随性点缀不对称的珍珠，营造视觉韵律',18500.00,15,22,'上架','https://example.com/images/tasaki_ambivalent_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.496605'),(54,'J004','Tasaki 南洋珍珠项链','精选南洋白珍珠，圆润饱满，光泽温润，搭配18K白金扣头，简约而不失优雅',28800.00,10,22,'上架','https://example.com/images/tasaki_south_sea_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.496605'),(55,'J005','Tasaki Akoya珍珠项链','经典Akoya珍珠项链，珍珠直径7.5-8mm，光泽细腻，适合日常佩戴',9800.00,30,22,'上架','https://example.com/images/tasaki_akoya_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.496605'),(56,'J006','Tasaki Linkage 珍珠耳环','18K樱花金与18K白金制成，镶嵌高品质钻石与阿古屋珍珠，闪耀星星点点的光影',12800.00,25,23,'上架','https://example.com/images/tasaki_linkage_earrings.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.499179'),(57,'J007','Tasaki Fluid 珍珠耳钉','流动的黄金线条包裹Akoya珍珠，简约而富有设计感',8800.00,35,23,'上架','https://example.com/images/tasaki_fluid_earrings.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.499179'),(58,'J008','Tasaki Androgynous 珍珠耳环','以黄金塑造出柔软而富生命力的不规则形态，一颗颗珍珠错落其间，中性而不失力量感',16800.00,18,23,'上架','https://example.com/images/tasaki_androgynous_earrings.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.499179'),(59,'J009','Tasaki 南洋珍珠耳环','南洋白珍珠与钻石的完美结合，18K白金镶嵌，优雅高贵',21800.00,12,23,'上架','https://example.com/images/tasaki_south_sea_earrings.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.499179'),(60,'J010','Tasaki Akoya珍珠耳钉','经典Akoya珍珠耳钉，简约百搭，适合各种场合',6800.00,40,23,'上架','https://example.com/images/tasaki_akoya_earrings.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.499179'),(61,'J011','Tasaki Linkage 珍珠戒指','18K金与珍珠的完美结合，设计灵感源自珍珠贝笼，独特而富有艺术感',15800.00,20,24,'上架','https://example.com/images/tasaki_linkage_ring.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.500155'),(62,'J012','Tasaki Fluid 珍珠戒指','流动的黄金线条环绕Akoya珍珠，如水波般柔美',11800.00,28,24,'上架','https://example.com/images/tasaki_fluid_ring.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.500155'),(63,'J013','Tasaki 南洋珍珠戒指','精选南洋珍珠，搭配钻石镶嵌，奢华而不张扬',25800.00,15,24,'上架','https://example.com/images/tasaki_south_sea_ring.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.500155'),(64,'J014','Tasaki Akoya珍珠戒指','经典Akoya珍珠戒指，简约优雅，适合日常佩戴',7800.00,35,24,'上架','https://example.com/images/tasaki_akoya_ring.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.500155'),(65,'J015','Tasaki 钻石珍珠戒指','钻石与珍珠的完美搭配，18K白金镶嵌，璀璨夺目',32800.00,10,24,'上架','https://example.com/images/tasaki_diamond_pearl_ring.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.500155'),(66,'J016','Tasaki Linkage 珍珠手链','18K金与珍珠的交织设计，灵感源自珍珠贝笼，优雅而富有层次',13800.00,22,25,'上架','https://example.com/images/tasaki_linkage_bracelet.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.501124'),(67,'J017','Tasaki Ambivalent 链环手链','长短不一的黄金曲线穿过圆形链环，两端点缀不对称珍珠，随动作轻轻摇晃',16800.00,18,25,'上架','https://example.com/images/tasaki_ambivalent_bracelet.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.501124'),(68,'J018','Tasaki 南洋珍珠手链','南洋白珍珠与18K白金的完美结合，优雅高贵',24800.00,12,25,'上架','https://example.com/images/tasaki_south_sea_bracelet.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.501124'),(69,'J019','Tasaki Akoya珍珠手链','经典Akoya珍珠手链，简约百搭，适合各种场合',8800.00,30,25,'上架','https://example.com/images/tasaki_akoya_bracelet.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.501124'),(70,'J020','Tasaki Passel 珍珠手链','升华自然的美丽与珍贵，珍珠与黄金的完美融合',19800.00,15,25,'上架','https://example.com/images/tasaki_passel_bracelet.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.501124'),(71,'J021','Tasaki Haute Joaillerie 祖母绿项链','复杂项链以不同琢形钻石勾勒花叶，镶嵌12颗总重近28ct枕形切割祖母绿，挂坠镶嵌11.44ct枕形祖母绿主石',288000.00,3,26,'上架','https://example.com/images/tasaki_emerald_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.502166'),(72,'J022','Tasaki Haute Joaillerie 蓝宝石项链','矩形链节交替镶嵌钻石和祖母绿型切割蓝宝石，垂落21.02ct祖母绿型切割蓝宝石吊坠',368000.00,2,26,'上架','https://example.com/images/tasaki_sapphire_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.502166'),(73,'J023','Tasaki Haute Joaillerie 红宝石项链','白金项链镶嵌44颗总重超过21ct水滴形切割红宝石，挂坠中央8.08ct水滴形切割鸽血红红宝石',428000.00,2,26,'上架','https://example.com/images/tasaki_ruby_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.502166'),(74,'J024','Tasaki Symphony of Light 钻石项链','以水滴形、榄尖形和圆形钻石连缀而成，每一颗宝石的尺寸和镶嵌角度都精心编排，如光之交响曲',588000.00,1,26,'上架','https://example.com/images/tasaki_symphony_diamond_necklace.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.502166'),(75,'J025','Tasaki 南洋珍珠高级珠宝套装','包含项链、耳环、戒指、手链的完整套装，精选顶级南洋珍珠与钻石，奢华至极',688000.00,1,26,'上架','https://example.com/images/tasaki_south_sea_parure.jpg',NULL,'2026-02-23 10:37:08.000000','2026-02-23 10:37:29.502166'),(76,'PROD_1771925343807','手镯','',1000000.00,9999,26,'上架','',NULL,'2026-02-24 09:29:03.809698','2026-02-24 09:48:09.000000');
/*!40000 ALTER TABLE `product` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `product_category`
--

DROP TABLE IF EXISTS `product_category`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `product_category` (
  `product_category_id` int NOT NULL AUTO_INCREMENT,
  `product_category_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_id` int DEFAULT NULL,
  `sort_order` int DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`product_category_id`)
) ENGINE=InnoDB AUTO_INCREMENT=27 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `product_category`
--

LOCK TABLES `product_category` WRITE;
/*!40000 ALTER TABLE `product_category` DISABLE KEYS */;
INSERT INTO `product_category` VALUES (1,'珠宝',NULL,0,1,NULL,'2026-02-23 09:56:48.880595','2026-02-23 09:56:48.880595'),(2,'电子产品',NULL,1,1,NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:15:22.000000'),(3,'服装鞋帽',NULL,2,1,NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:15:22.000000'),(4,'家居用品',NULL,3,1,NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:15:22.000000'),(5,'食品饮料',NULL,4,1,NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:15:22.000000'),(6,'美妆护肤',NULL,5,1,NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:15:22.000000'),(9,'男装',3,1,1,NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:40:09.267135'),(10,'女装',3,2,1,NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:40:09.267135'),(11,'运动鞋',3,3,1,NULL,'2026-02-23 10:15:22.000000','2026-02-23 10:40:09.267135'),(22,'珍珠项链',1,NULL,1,NULL,'2026-02-23 10:37:08.008207','2026-02-23 10:37:08.008207'),(23,'珍珠耳环',1,NULL,1,NULL,'2026-02-23 10:37:08.008207','2026-02-23 10:37:08.008207'),(24,'珍珠戒指',1,NULL,1,NULL,'2026-02-23 10:37:08.008207','2026-02-23 10:37:08.008207'),(25,'珍珠手链',1,NULL,1,NULL,'2026-02-23 10:37:08.008207','2026-02-23 10:37:08.008207'),(26,'高级珠宝',1,NULL,1,NULL,'2026-02-23 10:37:08.008207','2026-02-23 10:37:08.008207');
/*!40000 ALTER TABLE `product_category` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role`
--

DROP TABLE IF EXISTS `role`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role` (
  `role_id` int NOT NULL AUTO_INCREMENT,
  `role_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(255) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`role_id`),
  UNIQUE KEY `IDX_4810bc474fe6394c6f58cb7c9e` (`role_name`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role`
--

LOCK TABLES `role` WRITE;
/*!40000 ALTER TABLE `role` DISABLE KEYS */;
INSERT INTO `role` VALUES (1,'超级管理员','系统超级管理员，拥有所有权限',NULL,'2026-02-23 09:49:00.000000','2026-02-23 09:49:00.000000'),(2,'管理员','系统管理员，拥有大部分权限',NULL,'2026-02-23 09:49:00.000000','2026-02-23 09:49:00.000000'),(3,'客服','客服人员，负责客户服务和订单处理',NULL,'2026-02-23 09:49:00.000000','2026-02-23 09:49:00.000000'),(4,'运营','运营人员，负责活动和营销',NULL,'2026-02-23 09:49:00.000000','2026-02-23 09:49:00.000000');
/*!40000 ALTER TABLE `role` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `role_permission`
--

DROP TABLE IF EXISTS `role_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `role_permission` (
  `role_permission_id` int NOT NULL AUTO_INCREMENT,
  `role_id` int NOT NULL,
  `permission_id` int NOT NULL,
  `created_at` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`role_permission_id`),
  KEY `FK_3d0a7155eafd75ddba5a7013368` (`role_id`),
  KEY `FK_e3a3ba47b7ca00fd23be4ebd6cf` (`permission_id`),
  CONSTRAINT `FK_3d0a7155eafd75ddba5a7013368` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`),
  CONSTRAINT `FK_e3a3ba47b7ca00fd23be4ebd6cf` FOREIGN KEY (`permission_id`) REFERENCES `permission` (`permission_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `role_permission`
--

LOCK TABLES `role_permission` WRITE;
/*!40000 ALTER TABLE `role_permission` DISABLE KEYS */;
/*!40000 ALTER TABLE `role_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `user_id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `password` varchar(255) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_name` varchar(50) COLLATE utf8mb4_unicode_ci NOT NULL,
  `phone` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `role_id` int DEFAULT NULL,
  `position` varchar(50) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint NOT NULL DEFAULT '1',
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
  `updated_at` timestamp(6) NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
  PRIMARY KEY (`user_id`),
  UNIQUE KEY `IDX_78a916df40e02a9deb1c4b75ed` (`username`),
  UNIQUE KEY `IDX_8e1f623798118e629b46a9e629` (`phone`),
  UNIQUE KEY `IDX_e12875dfb3b1d92d7d7c5377e2` (`email`),
  KEY `FK_fb2e442d14add3cefbdf33c4561` (`role_id`),
  CONSTRAINT `FK_fb2e442d14add3cefbdf33c4561` FOREIGN KEY (`role_id`) REFERENCES `role` (`role_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (3,'admin','$2b$10$aGG3CAsSaaHWATBradcB5OX2wC6kB5UrsBHZYeef2AmpDC9//n8O6','系统管理员','13800138000','admin@junlite.com',1,'系统管理员',1,NULL,'2026-02-23 09:49:00.000000','2026-02-23 09:53:16.051894'),(4,'test','$2b$10$qfaOfz.Z/nkJHraFTM9Of.9PH/.r4YgCh6hOZqFVC/GgQFT0lfDtq','测试用户','13800138001','test@junlite.com',2,'测试人员',1,NULL,'2026-02-23 09:49:00.000000','2026-02-23 09:53:16.053747');
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Dumping events for database 'crm_db'
--

--
-- Dumping routines for database 'crm_db'
--
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2026-02-24 11:37:41
